fx_version 'adamant'
game 'gta5'
name "UPCODE-PAUSEMENU"
description "This resource is a clothing menu"
author "UPCODE"

client_scripts { 'shared/*', 'client/*' }

ui_page 'dist/index.html'

files {'dist/index.html', 'dist/assets/*'}